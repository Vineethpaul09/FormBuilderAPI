﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace FormBuilderAPI.Migrations
{
    /// <inheritdoc />
    public partial class ADDED_FormSections_Table_AND_Tenant_Table_and_updated_tables : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_FormFields_Forms_FormId",
                table: "FormFields");

            migrationBuilder.DropIndex(
                name: "IX_FormFields_FormId",
                table: "FormFields");

            migrationBuilder.DropColumn(
                name: "FormId",
                table: "FormFields");

            migrationBuilder.AddColumn<int>(
                name: "TenantId",
                table: "Forms",
                type: "int",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "FormSectionId",
                table: "FormFields",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.CreateTable(
                name: "FormSections",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Alignment = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ColumnsPerRow = table.Column<int>(type: "int", nullable: false),
                    FormId = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_FormSections", x => x.Id);
                    table.ForeignKey(
                        name: "FK_FormSections_Forms_FormId",
                        column: x => x.FormId,
                        principalTable: "Forms",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Tenants",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Description = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Tenants", x => x.Id);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Forms_TenantId",
                table: "Forms",
                column: "TenantId");

            migrationBuilder.CreateIndex(
                name: "IX_FormFields_FormSectionId",
                table: "FormFields",
                column: "FormSectionId");

            migrationBuilder.CreateIndex(
                name: "IX_FormSections_FormId",
                table: "FormSections",
                column: "FormId");

            migrationBuilder.AddForeignKey(
                name: "FK_FormFields_FormSections_FormSectionId",
                table: "FormFields",
                column: "FormSectionId",
                principalTable: "FormSections",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_Forms_Tenants_TenantId",
                table: "Forms",
                column: "TenantId",
                principalTable: "Tenants",
                principalColumn: "Id");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_FormFields_FormSections_FormSectionId",
                table: "FormFields");

            migrationBuilder.DropForeignKey(
                name: "FK_Forms_Tenants_TenantId",
                table: "Forms");

            migrationBuilder.DropTable(
                name: "FormSections");

            migrationBuilder.DropTable(
                name: "Tenants");

            migrationBuilder.DropIndex(
                name: "IX_Forms_TenantId",
                table: "Forms");

            migrationBuilder.DropIndex(
                name: "IX_FormFields_FormSectionId",
                table: "FormFields");

            migrationBuilder.DropColumn(
                name: "TenantId",
                table: "Forms");

            migrationBuilder.DropColumn(
                name: "FormSectionId",
                table: "FormFields");

            migrationBuilder.AddColumn<int>(
                name: "FormId",
                table: "FormFields",
                type: "int",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_FormFields_FormId",
                table: "FormFields",
                column: "FormId");

            migrationBuilder.AddForeignKey(
                name: "FK_FormFields_Forms_FormId",
                table: "FormFields",
                column: "FormId",
                principalTable: "Forms",
                principalColumn: "Id");
        }
    }
}
