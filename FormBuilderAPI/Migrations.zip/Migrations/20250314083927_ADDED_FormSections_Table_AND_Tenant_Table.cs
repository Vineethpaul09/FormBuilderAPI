﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace FormBuilderAPI.Migrations
{
    /// <inheritdoc />
    public partial class ADDED_FormSections_Table_AND_Tenant_Table : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_FormSections_Forms_FormId",
                table: "FormSections");

            migrationBuilder.AddForeignKey(
                name: "FK_FormSections_Forms_FormId",
                table: "FormSections",
                column: "FormId",
                principalTable: "Forms",
                principalColumn: "Id");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_FormSections_Forms_FormId",
                table: "FormSections");

            migrationBuilder.AddForeignKey(
                name: "FK_FormSections_Forms_FormId",
                table: "FormSections",
                column: "FormId",
                principalTable: "Forms",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
